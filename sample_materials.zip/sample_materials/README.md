Put sample college study PDFs in this folder if you want to keep them locally.

For the actual application, upload PDFs through:
Admin Dashboard -> Documents -> Upload & Build Knowledge Base

Do not commit copyrighted books or private documents to GitHub.
